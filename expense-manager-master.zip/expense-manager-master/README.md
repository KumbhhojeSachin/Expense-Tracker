# ExpenseManager
Expense Manager to track all the expenses built using Angular cli and Firebase.

# Live demo
https://expense-manager-2017.herokuapp.com

# Steps to Run the application locally
1. Fork/Clone the repository
2. Run `npm install`
3. After downloading all the modules, run `ng serve`
4. Goto `localhost:4200` (default port for Angular CLI).

